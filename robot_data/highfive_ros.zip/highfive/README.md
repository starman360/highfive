## High Five!

This is a project is to understand how to perform a high-five with a robot.